n=[83,25,50,70,14,74,68,90]
while True:
    fn = int(input("enter the number to find: "))
    for i in range(0,len(n)-1):
        if n[i]==fn:
            print("number found")
            break
    else: 
        print("the given is not in the list")
        break
    ch = input("continue[y/n]: ") 
    if ch in ('Y','y'):
        continue
    else:
        break

    
    
    
    
    
    