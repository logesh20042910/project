n=[83,25,67,50,70,14,74,90]
for i in range(1,len(n)):
    curval = n[i]
    curpos = i
    while curpos>0 and n[curpos-1]>curval:
        n[curpos]=n[curpos-1]
        curpos = curpos-1
        n[curpos] = curval
print(n)        