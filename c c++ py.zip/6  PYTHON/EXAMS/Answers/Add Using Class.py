class py345:
    def getdata(self):
        self.a = int(input("Enter 1st Num: "))
        self.b = int(input("Enter 2nd Num: "))
    def add(self):
        self.c=self.a+self.b        
    def Calculate(self):
        self.add()
        self.sub()
        self.mul()
        self.div()
    def sub(self):
        self.d=self.a-self.b
    def mul(self):
        self.e=self.a*self.b
    def div(self):
        self.f=self.a/self.b        
    def Showdata(self):
        print("Sum: ",self.c)
        print("Diff: ",self.d)
        print("mul: ",self.e)
        print("div: ",self.f)
pro = py345()
pro.getdata()
pro.Calculate()
pro.Showdata()
