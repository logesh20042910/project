// Bitwise Operators
#include<stdio.h>
#include<conio.h>
void main()
{
int a=5,b=7;
clrscr();
printf("\nAND = %d",a&b);
printf("\nOR = %d",a|b);
printf("\nNOT = %d",~a);
printf("\nXOR = %d",a^b);
printf("\nLEFT = %d",a<<2);
printf("\nRIGHT = %d",a>>2);
getch();
}